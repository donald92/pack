<html>
<h2>mypackage is a python package to compute recursion problems</h2>
<ul>
 <li>binomial</li>
 <li>fibunaci</li>
 <li></li>
 <li></li>
 <li></li>
</ul>
</html>
